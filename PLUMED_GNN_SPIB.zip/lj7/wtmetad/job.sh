#!/bin/bash
#SBATCH -t 72:00:00
#SBATCH --oversubscribe
#SBATCH -N 1
#SBATCH --ntasks=1
#SBATCH --job-name="lj7"
#SBATCH --mem-per-cpu 5G

module load openmpi/3.1.5/gcc/8.4.0/zen
source /scratch/zt1/project/tiwary-prj/user/zzou/libtorch-cuda/sourceme.sh
source /scratch/zt1/project/tiwary-prj/user/zzou/plumed-2.9.0-libtorch-cuda118/sourceme.sh


sed -i "s/^idum .*/idum $((RANDOM))/g" in

mpirun -n $SLURM_NTASKS plumed simplemd < in 
