import os
import numpy as np
import torch
from torch import nn
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, Batch
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GATv2Conv
from torch_geometric.nn import global_mean_pool,global_add_pool,global_max_pool
from torch_geometric.utils import to_dense_adj
from tqdm import tqdm
import glob
import pickle
import random
import time
from utils import prepare_data, DataNormalize
from gspib import gSPIB

if __name__ == '__main__':

    # Settings
    # ------------------------------------------------------------------------------
    
    # Random seed
    seed = np.random.randint(0,10000)
    print(f'Seed index is {seed}.', flush=True)
    
    # By default, we save all the results in subdirectories of the following path.
    base_path = "SPIB"

    # Model parameters
    # Time delay delta t in terms of # of minimal time resolution of the trajectory data
    dt = 40

    # Dimension of bottleneck
    z_dim = 2

    # Encoder type ('Linear' or 'Nonlinear')
    encoder_type = 'Linear'
    
    # Number of nodes in each hidden layer of the gnn layers
    gnn_channel = 8

    # Number of nodes in each hidden layer of the encoder
    neuron_num1 = 16

    # Number of nodes in each hidden layer of the encoder
    neuron_num2 = 16
    
    # dim of graph embeddings (need when using linear encoder)
    data_shape = 12

    # Training parameters
    batch_size = 128

    # tolerance of loss change for measuring the convergence of the training
    tolerance = 0.0005

    # Number of epochs with the change of the state population smaller than the threshold after which this iteration of the training finishes
    patience = 3

    # Minimum refinements 
    refinements = 12

    # Initial learning rate of Adam optimizer
    learning_rate = 1e-3

    # Hyper-parameter beta
    beta = 1e-2

    # number of state labels
    output_dim = 8

    # number of node features
    input_dim = 1
    
    # number of edge features
    edge_dim = 5

    # normalization
    data_transform = None

    # device
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda:0" if use_cuda else "cpu")

    # working directorys
    IB_path = './' + str(seed)
    
    # divide traj into mini-traj
    num_div = 5
    
 
    IB = gSPIB(input_dim=input_dim, output_dim=output_dim, data_shape=data_shape, edge_dim=edge_dim,
          encoder_type=encoder_type, z_dim=z_dim,  lagtime=dt,
          beta=beta, learning_rate=learning_rate, device=device, path=IB_path, UpdateLabel=True,
          neuron_num1=neuron_num1, neuron_num2=neuron_num2, gnn_channel=gnn_channel, data_transform=data_transform)
    IB = IB.to(device)
    print(IB, flush=True)
    
    print(f'Load dataset...', flush=True)
    
    path = './'
    file = open(path+'dataset.pickle', 'rb')
    traj_data = pickle.load(file)
    init_label = np.load('./init_labels.npy')
    
    print(f'Done loading trajectory. Total {len(traj_data)} frames are loaded and will be sliced into {num_div} slices.', flush=True)
    
    # Evenly divide the ultra-long trajectory
    divtraj = []
    divlabel = []
    for i in range(num_div):
        if i != num_div - 1:
            divtraj.append(traj_data[int(i * len(traj_data) / num_div):int((i + 1) * len(traj_data) / num_div)])
            divlabel.append(
                init_label[int(i * len(init_label) / num_div):int((i + 1) * len(init_label) / num_div)])
        else:
            divtraj.append(traj_data[int(i * len(traj_data) / num_div):])
            divlabel.append(init_label[int(i * len(init_label) / num_div):])
            
    # split data into train and test set
    indices = list(range(num_div))
    split = int(np.floor(0.2 * num_div))

    np.random.shuffle(indices)
    train_indices, test_indices = indices[split:], indices[:split]
    
    # prepare the dataset for spib training
    train_dataset, test_dataset = prepare_data(divtraj, divlabel, weight_list=None,
                                               output_dim=output_dim, lagtime=dt,
                                               train_indices=train_indices,
                                               test_indices=test_indices, device=device)
                                               
    IB_path = os.path.join(base_path, "spib")

    # Set random seed
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    # train model
    IB.fit(train_dataset, test_dataset, batch_size=batch_size, tolerance=tolerance, patience=patience, refinements=refinements, index=seed)
    
    # save torch model
    torch.save(IB, IB.output_path + '_final_SPIB%i.model' % seed)
    
    # save state dict
    torch.save({'model_state_dict': IB.state_dict()}, '_SPIB_state%i.pt' % seed)