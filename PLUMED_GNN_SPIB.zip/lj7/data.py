import numpy as np
import itertools
import glob
import os
from torch_geometric.utils import to_undirected
from torch_geometric.data import Data
import torch
import pickle
import pandas as pd
from tqdm import tqdm
import sys 

if __name__ == '__main__':

    rcut = 1.5 
    path = os.getcwd()
    nnode = 7
    dtype1 = torch.float
    dtype2 = torch.long
    
    npairs = list(itertools.combinations(np.arange(0,nnode), 2))
        
    dists = pd.read_csv(path+'/DISTANCE', delimiter=' ', skiprows=1, index_col=None, keep_date_col=True, header=None).values[:,2:]
        
    graphs = [] 
    for dist in tqdm(dists):
        mask = dist <= rcut
        edge_index = torch.tensor(npairs, dtype=dtype2)[mask]
        edge_feat1 = torch.tensor(dist, dtype=dtype1)[mask]
        
        edge_feat = edge_feat1.view(-1,1) 
        edge_index, edge_feat = to_undirected(edge_index.t(), edge_feat)
        
        data = Data(x=torch.ones((nnode,1),dtype=dtype1), edge_index=edge_index, edge_attr=edge_feat)
        
        graphs.append(data)
    
    del dists
    print('Done traj'+', now saving graph objects.', flush=True )
    with open('dataset.pickle', 'wb') as f:
        pickle.dump(graphs, f)
    