from torch import nn
import torch
from typing import Optional


class E_GCL(nn.Module):
    """
    E(n) Equivariant Convolutional Layer
    re
    """

    def __init__(self, input_nf, hidden_nf, output_nf, act_fn=nn.SiLU()):
        super(E_GCL, self).__init__()
        input_edge = input_nf * 2
        self.epsilon = 1e-8
        edge_coords_nf = 1

        self.edge_mlp = nn.Sequential(
            nn.Linear(input_edge + edge_coords_nf, hidden_nf),
            act_fn,
            nn.Linear(hidden_nf, hidden_nf),
            act_fn)

        self.node_mlp = nn.Sequential(
            nn.Linear(hidden_nf + input_nf, hidden_nf),
            act_fn,
            nn.Linear(hidden_nf, output_nf))

    def edge_model(self, source, target, radial):
        
        out = torch.cat([source, target, radial], dim=1)

        out = self.edge_mlp(out)

        return out

    def node_model(self, x, edge_index, edge_attr):
        row, col = edge_index[0], edge_index[1]
        agg = unsorted_segment_sum(edge_attr, row, num_segments=x.size(0))

        agg = torch.cat([x, agg], dim=1)
        out = self.node_mlp(agg)
        out = x + out 
        return out, agg

    def forward(self, h, edge_index, radial):
        row, col = edge_index[0], edge_index[1]
        
        edge_feat = self.edge_model(h[row], h[col], radial)
        h, agg = self.node_model(h, edge_index, edge_feat)

        return h


class EGNN(nn.Module):
    def __init__(self, in_node_nf, hidden_nf, out_node_nf, act_fn=nn.SiLU(), n_layers=2):
        '''

        :param in_node_nf: Number of features for 'h' at the input
        :param hidden_nf: Number of hidden features
        :param out_node_nf: Number of features for 'h' at the output
        :param in_edge_nf: Number of features for the edge features
        :param device: Device (e.g. 'cpu', 'cuda:0',...)
        :param act_fn: Non-linearity
        :param n_layers: Number of layer for the EGNN
        :param residual: Use residual connections, we recommend not changing this one
        :param attention: Whether using attention or not
        :param normalize: Normalizes the coordinates messages such that:
                    instead of: x^{l+1}_i = x^{l}_i + Σ(x_i - x_j)phi_x(m_ij)
                    we get:     x^{l+1}_i = x^{l}_i + Σ(x_i - x_j)phi_x(m_ij)/||x_i - x_j||
                    We noticed it may help in the stability or generalization in some future works.
                    We didn't use it in our paper.
        :param tanh: Sets a tanh activation function at the output of phi_x(m_ij). I.e. it bounds the output of
                        phi_x(m_ij) which definitely improves in stability but it may decrease in accuracy.
                        We didn't use it in our paper.
        '''

        super(EGNN, self).__init__()
        self.hidden_nf = hidden_nf
        self.n_layers = n_layers
        self.embedding_in = nn.Linear(in_node_nf, self.hidden_nf)
        self.embedding_out = nn.Linear(self.hidden_nf, out_node_nf)

        self.gcl1 = E_GCL(self.hidden_nf, self.hidden_nf, self.hidden_nf, act_fn=act_fn)
        self.gcl2 = E_GCL(self.hidden_nf, self.hidden_nf, self.hidden_nf, act_fn=act_fn)
        self.gcl3 = E_GCL(self.hidden_nf, self.hidden_nf, self.hidden_nf, act_fn=act_fn)


    def forward(self, h, edges, radial):
        h = self.embedding_in(h)
        
        h = self.gcl1(h, edges, radial)
        h = self.gcl2(h, edges, radial)
        h = self.gcl3(h, edges, radial)
        
        h = self.embedding_out(h)
        return h


def unsorted_segment_sum(data, segment_ids, num_segments:int):
    result_shape = [num_segments, data.size(1)]
    result = data.new_full(result_shape, 0)  # Init empty result tensor.
    segment_ids = segment_ids.unsqueeze(-1).expand(-1, data.size(1))
    result.scatter_add_(0, segment_ids, data)
    return result


def unsorted_segment_mean(data, segment_ids, num_segments:int):
    result_shape = [num_segments, data.size(1)]
    segment_ids = segment_ids.unsqueeze(-1).expand(-1, data.size(1))
    result = data.new_full(result_shape, 0)  # Init empty result tensor.
    count = data.new_full(result_shape, 0)
    result.scatter_add_(0, segment_ids, data)
    count.scatter_add_(0, segment_ids, torch.ones_like(data))
    return result / count.clamp(min=1)


def get_edges(n_nodes):
    rows, cols = [], []
    for i in range(n_nodes):
        for j in range(n_nodes):
            if i != j:
                rows.append(i)
                cols.append(j)

    edges = [rows, cols]
    return edges


def get_edges_batch(n_nodes, batch_size):
    edges = get_edges(n_nodes)
    edge_attr = torch.ones(len(edges[0]) * batch_size, 1)
    edges = [torch.LongTensor(edges[0]), torch.LongTensor(edges[1])] # (2,E)
    if batch_size == 1:
        return edges, edge_attr
    elif batch_size > 1:
        rows, cols = [], []
        for i in range(batch_size):
            rows.append(edges[0] + n_nodes * i)
            cols.append(edges[1] + n_nodes * i)
        edges = [torch.cat(rows), torch.cat(cols)]
    return edges, edge_attr


if __name__ == "__main__":
    # Dummy parameters
    batch_size = 8
    n_nodes = 4
    n_feat = 1
    x_dim = 3

    

