import os
import numpy as np
import torch
from torch import nn
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.data import Data, Dataset, Batch
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GATv2Conv, CGConv, NNConv, SimpleConv
from torch_geometric.nn import global_mean_pool,global_add_pool,global_max_pool
from torch_geometric.utils import to_dense_adj, to_undirected
from tqdm import tqdm
import glob
import pickle
import random
import time
from utils import prepare_data, DataNormalize
from gspib import gSPIB
from egnn import E_GCL, EGNN

import torch.jit as jit
from typing import Optional


class gSPIBjit(jit.ScriptModule):
    def __init__(self, IB):
        super(gSPIBjit, self).__init__()

        self.encoder_mean = IB.encoder_mean
        self.egnn = IB.egnn
        
        self.decoder = IB.decoder
        self.decoder_output = IB.decoder_output
        
    @jit.script_method
    def forward(self, x, edge_index, radial, batch: Optional[torch.Tensor]=None):
    
        x = self.egnn(x, edge_index.to(torch.long), radial) 
        
        global_pool = [global_mean_pool(x, None), global_max_pool(x, None)]
        x = torch.cat(global_pool, dim=-1)
        z_mean = self.encoder_mean(x)
        dec = self.decoder(z_mean)
        outputs = self.decoder_output(dec)

        return outputs
        
if __name__ == '__main__':

    seed = 9676

    IB = torch.load(glob.glob(str(seed)+'*.model')[0] , map_location=torch.device('cpu') )
    
    jit_model = gSPIBjit(IB)
    
    jit_model.eval()
    scripted_model = torch.jit.script(jit_model)
    scripted_model.save('model_full'+str(seed)+'.pt')
    print('Mdeol saved', flush=True)
