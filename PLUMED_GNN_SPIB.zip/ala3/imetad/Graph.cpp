/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   Copyright (c) 2012-2019 The plumed team
   (see the PEOPLE file at the root of the distribution for a list of names)

   See http://www.plumed.org for more information.

   This file is part of plumed, version 2.

   plumed is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   plumed is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with plumed.  If not, see <http://www.gnu.org/licenses/>.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* ----------------------------------------------------------------------
------------------------------------------------------------------------- */
#include "colvar/Colvar.h"
#include "core/ActionRegister.h"
#include "core/Atoms.h"
#include "tools/Tools.h"
#include "tools/Angle.h"
#include "tools/IFile.h"

#include <torch/torch.h>
#include <torch/script.h>
#include <cmath>
#include <string>
#include <math.h>
#include <iostream>
#include <vector>
#include <assert.h>  

using namespace std;

namespace PLMD{
namespace colvar{


class GraphGenerator: 
  public Colvar
{
  bool serial,pbc;
  vector<AtomNumber> atom_lista;
  std::vector<PLMD::AtomNumber> atomsToRequest;
  double rcut, rcut2;
  unsigned _n_out, nat;
  torch::jit::script::Module _model;
  torch::Device device = torch::kCPU;
    
public:
  explicit GraphGenerator(const ActionOptions&);
  void calculate();
  static void registerKeywords( Keywords& keys );
  std::vector<float> tensor_to_vector(const torch::Tensor& x);

};

PLUMED_REGISTER_ACTION(GraphGenerator,"GRAPH")

void GraphGenerator::registerKeywords( Keywords& keys ){
  Colvar::registerKeywords(keys);
  keys.addFlag("SERIAL",false,"Perform the calculation in serial");
  keys.add("atoms","ATOMS","Reference particles for constructing graphs");
  keys.add("compulsory","RCUT","1.0","Radius nearest neighbor for creating neighorlist"); // 
  keys.add("optional","MODEL","filename of the trained model"); 
  keys.addOutputComponent("node", "default", "NN outputs"); 

}

std::vector<float> GraphGenerator::tensor_to_vector(const torch::Tensor& x) {
  return std::vector<float>(x.data_ptr<float>(), x.data_ptr<float>() + x.numel());
}

GraphGenerator::GraphGenerator(const ActionOptions&ao):
  PLUMED_COLVAR_INIT(ao),
  pbc(true),
  serial(false)
{
  parseFlag("SERIAL",serial);
  parseAtomList("ATOMS", atom_lista); // list of node (Z) 

  parse("RCUT",rcut); // read radius cutoff parameter (Z)
  if( rcut< 0.0 ) error("Please set RCUT larger than 0.0\n");
  rcut2=rcut*rcut;
  log.printf("  The neighbor is defined by a radius of %f nm.\n", rcut);
      
  //parse model name
  std::string fname="model.pt";
  parse("MODEL",fname); 
      
  //deserialize the model from file
  try {
    _model = torch::jit::load(fname, device);
  }
  //if an error is thrown check if the file exists or not
  catch (const c10::Error& e) {
    std::ifstream infile(fname);
    bool exist = infile.good();
    infile.close();
    if (exist) {
      plumed_merror("Cannot load FILE: '"+fname+"'. Please check that it is a Pytorch compiled model (exported with 'torch.jit.trace' or 'torch.jit.script').");
    }
    else {
      plumed_merror("The FILE: '"+fname+"' does not exist.");
    }
  }
  
  checkRead();
  // Optimize model
  _model.eval();
#ifdef DO_TORCH_FREEZE_HACK
  // Do the hack
  // Copied from the implementation of torch::jit::freeze,
  // except without the broken check
  // See https://github.com/pytorch/pytorch/blob/dfbd030854359207cb3040b864614affeace11ce/torch/csrc/jit/api/module.cpp
  bool optimize_numerics = true;  // the default
  // the {} is preserved_attrs
  auto out_mod = torch::jit::freeze_module(
                   _model, {}
                 );
  // See 1.11 bugfix in https://github.com/pytorch/pytorch/pull/71436
  auto graph = out_mod.get_method("forward").graph();
  OptimizeFrozenGraph(graph, optimize_numerics);
  _model = out_mod;
#else
  // Do it normally
  _model = torch::jit::freeze(_model);
#endif

  // Optimize model for inference
#if (TORCH_VERSION_MAJOR == 2 || TORCH_VERSION_MAJOR == 1 && TORCH_VERSION_MINOR >= 10)
  _model = torch::jit::optimize_for_inference(_model);
#endif
 
  nat = atom_lista.size();

        
  //check the dimension of the output
  log.printf("Checking output dimension:\n");
  std::vector<int> input_test1 ( nat*(nat-1)*2 ); // edge index vector
  std::vector<float> input_test2 ( nat*(nat-1) ); // edge feature vector
  std::vector<float> input_test3 ( nat*3 ); // node feature vector
      
  torch::Tensor single_input1 = torch::tensor(input_test1, torch::dtype(torch::kInt64)).view({2,-1}).to(device); 
  torch::Tensor single_input2 = torch::tensor(input_test2).view({-1,1}).to(device);
  torch::Tensor single_input3 = torch::tensor(input_test3).view({-1,3}).to(device);  
  
  std::vector<torch::jit::IValue> inputs;
  
  inputs.push_back( single_input3 );
  inputs.push_back( single_input1 );
  inputs.push_back( single_input2 );
  torch::Tensor output = _model.forward( inputs ).toTensor(); 
  vector<float> cvs = this->tensor_to_vector (output);
  _n_out=cvs.size();

  //create components
  for(unsigned j=0; j<_n_out; j++){
    string name_comp = "node-"+std::to_string(j);
    addComponentWithDerivatives( name_comp );
    componentIsNotPeriodic( name_comp );
  }
  
  //print log
  //log.printf("Pytorch Model Loaded: %s \n",fname);
  log.printf("Number of outputs: %d \n",_n_out);
      
  atomsToRequest.reserve ( atom_lista.size() ); // Initilization of atoms list (Z)
  atomsToRequest.insert (atomsToRequest.end(), atom_lista.begin(), atom_lista.end() ); // (Z)
  requestAtoms(atomsToRequest); // need to put this after components declaring as it creates derivatives (Z)
}

// generator
void GraphGenerator::calculate()
{
	
  if(pbc) makeWhole();
  // clock_t begin_time = clock();
  // Setup parallelization
  unsigned stride = comm.Get_size();
  unsigned rank = comm.Get_rank();
  if(serial){
    stride = 1;
    rank = 0;
  } else {
    stride = comm.Get_size();
    rank = comm.Get_rank(); // Somehow it is always rank=0. Does MPI really work? (T)
  }
  
  Matrix<double> dist_mat(nat, nat);
  Matrix<Vector> dist_deriv_mat(nat, nat);
  vector<int> idx_vec;
  idx_vec.reserve(nat*(nat-1));
  
  for(unsigned int i=0;i<nat;i++) {
      
    for(unsigned int j=0;j<nat;j++) {
	  double d2;
      Vector distance;
	  if(getAbsoluteIndex(i)==getAbsoluteIndex(j)) {
	    continue;
	  }
	  distance=delta(getPosition(i),getPosition(j));
      const double value=distance.modulo();
      const double invvalue=1.0/value;
      dist_mat[i][j] = value;
      dist_deriv_mat[i][j] = -1.0*invvalue*distance; // 
      idx_vec.push_back(i*nat+j);
// 	  }
    }
  }
  idx_vec.shrink_to_fit();
  
  //declare variables for model
  vector<double> input1(idx_vec.size()); // edge feature vector
  vector<double> input21(idx_vec.size()); // edge index vector 1 (node index)
  vector<double> input22(idx_vec.size()); // edge index vector 2 (neighbor index)
  vector<double> input3(nat*3, 1); // node feature vector
  vector<Vector> dist_dir_vector(idx_vec.size()); 

  for(unsigned i=0;i<idx_vec.size();i++) {
	unsigned int nn=idx_vec[i]/nat;
	unsigned int mm=idx_vec[i]%nat;
	
	input1[i]=dist_mat[nn][mm];
	input21[i]=nn;
	input22[i]=mm;
	dist_dir_vector[i]=dist_deriv_mat[nn][mm];
  }
  
  // cout << float( clock () - begin_time ) << " ";
  // begin_time = clock();

  //convert to tensor
  torch::Tensor input_efeat = torch::tensor(input1).view({-1,1}).to(device);
  input_efeat.set_requires_grad(true);
  torch::Tensor input_idxn1 = torch::tensor(input21, torch::dtype(torch::kInt64)).view({1,-1}).to(device);
  input_idxn1.set_requires_grad(false);
  torch::Tensor input_idxn2 = torch::tensor(input22, torch::dtype(torch::kInt64)).view({1,-1}).to(device);
  input_idxn2.set_requires_grad(false);
  torch::Tensor input_idxn = torch::cat({input_idxn1, input_idxn2}, /*dim=*/0).to(device);
  input_idxn.set_requires_grad(false);
  torch::Tensor input_nfeat = torch::tensor(input3).view({-1,3}).to(device); // dummy input
  input_nfeat.set_requires_grad(false);
  
  // cout << "input1 \n";
  // cout << input_efeat << " ";
  
  //convert to Ivalue
  std::vector<torch::jit::IValue> input;
  input.push_back( input_nfeat );
  input.push_back( input_idxn );
  input.push_back( input_efeat );
  //calculate output
  torch::Tensor output = _model.forward( input ).toTensor();  
  //set CV values
  vector<float> cvs = this->tensor_to_vector (output);
  // cout << float( clock () - begin_time ) << " ";
  // begin_time = clock();
  
  //derivatives
  for(unsigned j=0; j<_n_out; j++) {
    // expand dim to have shape (1,_n_out)
    int batch_size = 1;
    torch::Tensor grad_output = torch::ones({1}).expand({batch_size, 1}).to(device);
    // calculate derivatives with automatic differentiation

	auto gradient = torch::autograd::grad({output.slice(/*dim=*/1, /*start=*/j, /*end=*/j+1)},
    /*outputing gradient will have the same shape to this input*/{input_efeat},
    /*grad_outputs=*/ {grad_output},
    /*retain_graph=*/true,
    /*create_graph=*/false);  // same shape to input_efeat;
    // add dimension
    torch::Tensor grad = gradient[0].unsqueeze(/*dim=*/1);
    //convert to vector
	vector<float> der = this->tensor_to_vector( grad );
    vector<Vector> deriv(nat);
    Tensor virial;
    //compute derivatives
    for(unsigned int i=rank;i<idx_vec.size();i+=stride) {
      deriv[input21[i]] += dist_dir_vector[i]*der[i];
      deriv[input22[i]] += -1.0*dist_dir_vector[i]*der[i];
        
      if(!pbc) {
        Vector vv = delta(getPosition(input21[i]),getPosition(input22[i]));
        Tensor vd(-1.0*dist_dir_vector[i]*der[i], vv);
        virial += vd;
      }
	} 

    //set derivatives of component j
    string name_comp = "node-"+std::to_string(j);
    Value* value = getPntrToComponent(name_comp);
    for(unsigned k=0; k<nat; k++) {
      setAtomsDerivatives( value, k, deriv[k] );
    }
  
    if(!pbc) {setBoxDerivatives( value, virial );} else {setBoxDerivativesNoPbc(value); }
	value->set(cvs[j]);
  }

  // cout << float( clock () - begin_time ) << "\n";

}

}

}