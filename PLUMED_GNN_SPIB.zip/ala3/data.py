import numpy as np
import itertools
import glob
import os
import torch.nn.functional as F
from torch_geometric.utils import to_undirected
from torch_geometric.data import Data
import torch
import pickle
import pandas as pd
from tqdm import tqdm
import sys 
import mdtraj as md

if __name__ == '__main__':

    traj = md.load('./md/md.trr', top='./md/ala3.gro')
    atom_indices = traj.topology.select_atom_indices(selection='heavy')
    subtraj = traj.restrict_atoms(atom_indices)
    dtype1 = torch.float
    dtype2 = torch.long
    bond = subtraj.topology.to_dataframe()[1]
    index = subtraj.topology.to_dataframe()[0].values[:,2]
    index[index == 'C'] = 0
    index[index == 'N'] = 1
    index[index == 'O'] = 2 
    index = np.array(index,dtype=int)
    index = F.one_hot(torch.tensor(index, dtype=dtype2))
    conect = bond[:,:2]
    conect = torch.tensor(conect.T, dtype=torch.long)
    graphs = []

    pairs = list(itertools.permutations(np.arange(subtraj.top.n_atoms),2))

    for t in tqdm(range(1000000)): # 1 ms unbiased traj to graph data
        xyz = subtraj[t].xyz.squeeze()
        box = np.diag(subtraj[t].unitcell_vectors.squeeze()).reshape(1,-1)
        
        edge_index = torch.tensor(pairs, dtype=dtype2).t()
        
        edge_attr = torch.tensor(md.compute_distances(subtraj[t], pairs, periodic=False).squeeze(), dtype=dtype1).view(-1,1)

        data = Data(x=index.to(dtype1), 
                    edge_index=edge_index, 
                    edge_attr=edge_attr.to(dtype1) 
                    )
        
        graphs.append(data)
    
    print(graphs[0], flush=True)
    print('Done traj'+', now saving graph objects.', flush=True )
    with open('dataset.pickle', 'wb') as f:
        pickle.dump(graphs, f)

    del graphs
    