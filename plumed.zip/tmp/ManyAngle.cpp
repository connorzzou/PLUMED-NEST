/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   Copyright (c) 2011-2016 The plumed team
   (see the PEOPLE file at the root of the distribution for a list of names)

   See http://www.plumed.org for more information.

   This file is part of plumed, version 2.

   plumed is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   plumed is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with plumed.  If not, see <http://www.gnu.org/licenses/>.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
#include "colvar/Colvar.h"
#include "colvar/ActionRegister.h"
#include "tools/Communicator.h"
#include "tools/Tools.h"
#include "tools/Angle.h"
#include "tools/IFile.h"
//#include "tools/MultiValue.h"

#include <string>
#include <math.h>

using namespace std;

namespace PLMD{
namespace colvar{

//+PLUMEDOC COLVAR MANY_ANGLE
/*

\plumedfile
This is a new version of many_angle OP with adding not only mean value but 2-nd moment being computed
LOAD FILE=ManyAnglePlus.cpp

# Define groups for the CV
C: GROUP ATOMS=1-864:8
O: GROUP ATOMS=2-864:8
N1: GROUP ATOMS=3-864:8
N2: GROUP ATOMS=6-864:8

MANY_ANGLE ...
 LABEL=ma
 CENTER=C
 START=N1
 END=N2
 RCUT=0.64
 MEAN
 MOMENT2
... MANY_ANGLE

PRINT STRIDE=1  ARG=* FILE=COLVAR
\endplumedfile

*/
//+ENDPLUMEDOC

class ManyAngle : public Colvar {
  bool pbc, serial, mean, moment2;
  vector<AtomNumber> center_lista, start_lista, end_lista;
  std::vector<PLMD::AtomNumber> atomsToRequest;
  double rcut, rcut2;
  // Up-down symmetry
  bool doUpDownSymmetry;
  // Low communication variant
  Value* moments[2]; // store components (Z)
public:
  explicit ManyAngle(const ActionOptions&);
  virtual void calculate();
  static void registerKeywords( Keywords& keys );
};

PLUMED_REGISTER_ACTION(ManyAngle,"MANY_ANGLE")

void ManyAngle::registerKeywords( Keywords& keys ){
  Colvar::registerKeywords(keys);
  keys.addFlag("SERIAL",false,"Perform the calculation in serial - for debug purpose");
  keys.add("atoms","CENTER","Center atoms");
  keys.add("atoms","START","Start point of vector defining orientation");
  keys.add("atoms","END","End point of vector defining orientation");
  keys.add("compulsory","RCUT","1","Maximum distance for being neighbor");
  //keys.addFlag("UP_DOWN_SYMMETRY",false,"The symmetry is such that parallel and antiparallel vectors are not distinguished. The angle goes from 0 to pi/2 instead of from 0 to pi.");
  //keys.addFlag("LOW_COMM",false,"Use an algorithm with less communication between processors");
  // componentsAreNotOptional(keys); // always return components w/o any additional flags (Z)
  keys.addFlag("MEAN",false,"Print mean of multicolvar"); // (Z)
  keys.addFlag("MOMENT2",false,"Print 2nd moment of multicolvar"); // (Z)
  keys.addOutputComponent("mean","default","Return the 1st moment of angle variable"); //(Z)
  keys.addOutputComponent("moment2","default","Return the 2nd moment of angle variable"); //(Z)
}

ManyAngle::ManyAngle(const ActionOptions&ao):
  PLUMED_COLVAR_INIT(ao),
  pbc(true), // initiating booleans 
  mean(false),
  moment2(false),
  serial(false)
{  
  parseFlag("SERIAL",serial);
  parseFlag("MEAN",mean); // read input flags (Z)
  parseFlag("MOMENT2",moment2); // (Z)
  parseAtomList("CENTER",center_lista);
  parseAtomList("START",start_lista);
  parseAtomList("END",end_lista);
  if(center_lista.size()!=start_lista.size()) error("Number of atoms in START must be equal to the number of atoms in CENTER");
  if(center_lista.size()!=end_lista.size()) error("Number of atoms in END must be equal to the number of atoms in CENTER");
  
  bool nopbc=!pbc;
  parseFlag("NOPBC",nopbc);
  pbc=!nopbc;

  if(pbc) log.printf("  using periodic boundary conditions\n");
  else    log.printf("  without periodic boundary conditions\n");

  // on how to add components refer cell.cpp (Z)
  if(mean) addComponentWithDerivatives("mean"); componentIsNotPeriodic("mean"); moments[0]=getPntrToComponent("mean"); // (Z)
  if(moment2) addComponentWithDerivatives("moment2"); componentIsNotPeriodic("moment2"); moments[1]=getPntrToComponent("moment2"); // (Z)
  if(!mean && !moment2) error( " Nothing Will Be Returned: Use MEAN or MOMENT2 to corresponding quantities.\n "); // error return (Z)

  parse("RCUT",rcut);
  log.printf("  The neighbor is defined within 0 and %f \n", rcut);
  rcut2 = rcut*rcut;

  // doUpDownSymmetry=false;
  // parseFlag("UP_DOWN_SYMMETRY",doUpDownSymmetry);
  // if (doUpDownSymmetry) log.printf("  The angle can take values between 0 and pi/2 due to the up down symmetry. \n");

  //doLowComm=false;
  //parseFlag("LOW_COMM",doLowComm);
  //if (doLowComm) {
  //   log.printf("  Using the low communication variant of the algorithm");
  //}

  checkRead();

  atomsToRequest.reserve ( center_lista.size() + start_lista.size() + end_lista.size() );
  atomsToRequest.insert (atomsToRequest.end(), center_lista.begin(), center_lista.end() );
  atomsToRequest.insert (atomsToRequest.end(), start_lista.begin(), start_lista.end() );
  atomsToRequest.insert (atomsToRequest.end(), end_lista.begin(), end_lista.end() );
  requestAtoms(atomsToRequest);

}

// calculator
void ManyAngle::calculate()
{
  double cv=0.0; // (T)
  double cvSqr=0.0; // sum of squared CVs (Z)
  unsigned nat=getNumberOfAtoms();
  vector<Vector> deriv(nat*2); // This will initialized vector with 0 modulo. (T)
  // vector<Vector> deriv_dcv_dr(nat); // Vector for dcv_dr. (Z)
  unsigned int num_cv=0; // (T)

  if(pbc) makeWhole();
  // Setup parallelization
  unsigned stride = comm.Get_size();
  unsigned rank = comm.Get_rank();
  if(serial){
    stride = 1;
    rank = 0;
  } else {
    stride = comm.Get_size();
    rank = comm.Get_rank(); // Somehow it is always rank=0. Does MPI really work? (T)
  }
  for(unsigned int i=rank;i<(center_lista.size()-1);i+=stride) {
      unsigned atom1_mol1=i+center_lista.size();
      unsigned atom2_mol1=i+center_lista.size()+start_lista.size();
      Vector dik=pbcDistance(getPosition(atom2_mol1),getPosition(atom1_mol1));
      for(unsigned int j=i+1;j<center_lista.size();j+=1) {
        double d2=0.0;
        Vector distance;
        if(getAbsoluteIndex(i)==getAbsoluteIndex(j)) continue;
        if(pbc){
         distance=pbcDistance(getPosition(i),getPosition(j));
        } else {
         distance=delta(getPosition(i),getPosition(j));
        }

        if ( (d2=distance[0]*distance[0])<rcut2 && (d2+=distance[1]*distance[1])<rcut2 && (d2+=distance[2]*distance[2])<rcut2) {
          unsigned atom1_mol2=j+center_lista.size();
          unsigned atom2_mol2=j+center_lista.size()+start_lista.size();
          Vector dij=pbcDistance(getPosition(atom1_mol2),getPosition(atom2_mol2));

          Vector ddij,ddik; // (T)
          PLMD::Angle a; // (T)
          double angle=a.compute(dij,dik,ddij,ddik); // (T)
          
          double xi=tanh(20.0*(angle-0.5*pi)); // (T)

          double pa=pi-2.0*angle; // (T)
          double curr=0.5*(pa*xi + pi); // (Z)
          cv += curr; // (T)
          double dcv_dangle=10.0*pa*(1.0-xi*xi)-xi; // (T)
          cvSqr += curr*curr; // (Z) sqaure sum
          

          // Perform chain rule. d(cv)/d(angle)*d(angle)/d(dik)
          deriv[atom1_mol1]+=dcv_dangle*ddik; // (T)
          deriv[atom2_mol1]+=-dcv_dangle*ddik; // (T)
          deriv[atom1_mol2]+=-dcv_dangle*ddij; // (T)
          deriv[atom2_mol2]+=dcv_dangle*ddij; // (T)
          deriv[atom1_mol1+nat]+=2*curr*dcv_dangle*ddik; // (Z)
          deriv[atom2_mol1+nat]+=-2*curr*dcv_dangle*ddik; // (Z)
          deriv[atom1_mol2+nat]+=-2*curr*dcv_dangle*ddij; // (Z)
          deriv[atom2_mol2+nat]+=2*curr*dcv_dangle*ddij; // (Z)

          num_cv++; // (T)

        }
      }
  }

  // Sum up CVs if parallelized w/ mpirun (Z)
  if(!serial){
    comm.Sum(cv);
    comm.Sum(cvSqr);
    comm.Sum(num_cv);
    //for(unsigned i=rank;i<center_lista.size();i+=stride){ 
    //for(unsigned int i=0;i<nat;++i){
    comm.Sum(deriv);
    //}
  }
  // Assign output quantities
  Tensor virial; // (T)
  Tensor virial_moment2; // (Z)
  double numSqr=num_cv*num_cv; // (Z)
  for(unsigned i=0;i<(nat);++i){ 
    // If atom 3 is involved in calculation of 2 angles when there are 3 angles being actually calculated, 
    // This derivatives of atom 3 will be the sum of derivatives of atom 3 calculated in each angle divided
    // by 3 (angles).
    vector<Vector> temp_deriv(1); // store current derivative as a vector (Z)
    temp_deriv[0]=deriv[i+nat]/(num_cv)-2*cv*deriv[i]/(numSqr); // (Z)

    setAtomsDerivatives(moments[0], i, deriv[i]/num_cv); // derivative of 1st moment (T)
    setAtomsDerivatives(moments[1], i, temp_deriv[0]); // derivative of 2nd moment (Z)
    // This line is calculated in the same way as what has been defined in Colvar::setBoxDerivativesNoPbc(Value* v).
    virial-=Tensor(getPosition(i), deriv[i]/num_cv); // (T)
    virial_moment2-=Tensor(getPosition(i), temp_deriv[0]); // (Z)

  }
  moments[0]->set( cv/num_cv ); // (T)
  setBoxDerivatives(moments[0], virial); // (T)
  //moments[0]->set( deriv[200].modulo() ); // derivative test DEBUGGING(Z) 


  double moment2 = (cvSqr/num_cv) - (cv*cv/numSqr); // (Z) SquredSum - SumSqure = variance      
  moments[1]->set( moment2 ); // (Z) 
  //moments[1]->set( deriv[200+nat].modulo() ); // derivative test DEBUGGING(Z) 
  setBoxDerivatives(moments[1], virial_moment2); // (Z)
  
  }

}


}

